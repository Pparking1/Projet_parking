-- 
-- Editor SQL for DB table utilisateur
-- Created by http://editor.datatables.net/generator
-- 

CREATE TABLE IF NOT EXISTS `utilisateur` (
	`id` int(10) NOT NULL auto_increment,
	`Prenom_utilisateur` varchar(255),
	`Nom_utilisateur` varchar(255),
	`adresse_utilisateur` varchar(255),
	`ville_utilisateur` varchar(255),
	`Numero_de_telephone_utilisateur` varchar(255),
	`E_mail_utilisateur` varchar(255),
	`metier_utilisateur` varchar(255),
	PRIMARY KEY( `id` )
);